import React, { Component } from 'react';

export default class Loading extends Component {
    render() {
        return (
            <div className="container">
                <img src="/imgs/loading.svg" alt="loading"/>
            </div>
        )
    }
}
