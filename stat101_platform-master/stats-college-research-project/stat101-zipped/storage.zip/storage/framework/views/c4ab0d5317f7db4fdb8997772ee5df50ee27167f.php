<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <link href="/css/app.css" rel="stylesheet" type="text/css"/>
        <link href="/css/styles.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
        <div id="index"></div>
        <script src="/js/app.js"></script>
    </body>
</html>
<?php /**PATH /Users/kevinweng/Documents/stat101/stat101_platform/stats-college-research-project/stat101/resources/views/welcome.blade.php ENDPATH**/ ?>